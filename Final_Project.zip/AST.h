//Abstract Syntax Tree Implementation
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

struct AST{
	char nodeType[50];
	char LHS[50];
	char RHS[50];
	
	struct AST * left;
	struct AST * right;
	// review pointers to structs in C 
	// complete the tree struct with pointers
};



struct AST * AST_assignment(char nodeType[50], char LHS[50], char RHS[50]) {
	

	//finish this function for final project
	struct AST* ASTAssign = malloc((sizeof(struct AST)));
	strcpy(ASTAssign->nodeType,nodeType);
	strcpy(ASTAssign->LHS,LHS);
	strcpy(ASTAssign->RHS,RHS);

/*
       =
	 /   \
	x     y

*/	
	return ASTAssign;
	
}
struct AST * AST_BinaryExpression(char nodeType[50], char LHS[50], char RHS[50]) {

	//finish this function for final peoject
	struct AST* ASTAssign = malloc(sizeof *ASTAssign);
	strcpy(ASTAssign->nodeType,nodeType);
	strcpy(ASTAssign->LHS,LHS);
	strcpy(ASTAssign->RHS,RHS);
	if(strcmp(nodeType, "+") == 0){
		return 1;
	}
	if(strcmp(nodeType, "-") == 0){
		return 2;
	}
	if(strcmp(nodeType, "*") == 0){
		return 3;
	}
	if(strcmp(nodeType, "-") == 0){
		return 4;
	}
	return -1;
}
struct AST * AST_Type(char nodeType[50], char LHS[50], char RHS[50]) {

	//finish this function for final project
	struct AST* ASTAssign = malloc(sizeof *ASTAssign);
	strcpy(ASTAssign->nodeType,nodeType);
	strcpy(ASTAssign->LHS,LHS);
	strcpy(ASTAssign->RHS,RHS);
	return ASTAssign;
}

struct AST * AST_Func(char nodeType[50], char LHS[50], char RHS[50]) {
	
	//finish this function for the final project
	struct AST* ASTAssign = malloc(sizeof *ASTAssign);
	strcpy(ASTAssign->nodeType,nodeType);
	strcpy(ASTAssign->LHS,LHS);
	strcpy(ASTAssign->RHS,RHS);

}
struct AST * AST_Write(char nodeType[50], char LHS[50], char RHS[50]) {
	
	//finish this function for the final project
	struct AST* ASTAssign = malloc(sizeof *ASTAssign);
	strcpy(ASTAssign->nodeType,nodeType);
	strcpy(ASTAssign->LHS,LHS);
	strcpy(ASTAssign->RHS,RHS);
}

void printDots(int num) {
	for (int i = 0; i < num; i++)
		printf("      ");
}

void printAST(struct AST* tree, int level) {
    
       //finish this function for the final project
    if (tree == NULL)
        return;
    if (level == 1)
        printf("%d ", tree);
    else if (level > 1) {
        printAST(tree->left, level - 1);
        printAST(tree->right, level - 1);
	}
}


